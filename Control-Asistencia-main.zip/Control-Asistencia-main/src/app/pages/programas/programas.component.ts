import { Component } from '@angular/core';

@Component({
  selector: 'app-programas',
  standalone: true,
  imports: [],
  templateUrl: './programas.component.html',
  styleUrl: './programas.component.scss'
})
export class ProgramasComponent {

}
