import { Component } from '@angular/core';

@Component({
  selector: 'app-profesores',
  standalone: true,
  imports: [],
  templateUrl: './profesores.component.html',
  styleUrl: './profesores.component.scss'
})
export class ProfesoresComponent {

}
