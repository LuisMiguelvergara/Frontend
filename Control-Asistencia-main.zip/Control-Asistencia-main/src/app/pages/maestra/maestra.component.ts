import { Component } from '@angular/core';

@Component({
  selector: 'app-maestra',
  standalone: true,
  imports: [],
  templateUrl: './maestra.component.html',
  styleUrl: './maestra.component.scss'
})
export class MaestraComponent {

}
